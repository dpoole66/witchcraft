Google ARCore SDK
=====================
Copyright (c) 2017 Google Inc.  All rights reserved.

[https://developers.google.com/ar/develop/unity/getting-started](https://developers.google.com/ar/develop/unity/getting-started)

Please note, we do not accept pull requests.